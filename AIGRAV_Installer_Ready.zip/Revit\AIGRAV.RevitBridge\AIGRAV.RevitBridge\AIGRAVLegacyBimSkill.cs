using AIGRAV.Contracts;
using Autodesk.Revit.UI;

namespace AIGRAV.RevitBridge;

/// <summary>
/// Adapter around the current stable AIGRAVToolExecutor.
/// This remains the fallback engine while specialized skills are introduced.
/// </summary>
public sealed class AIGRAVLegacyBimSkill : IAIGRAVSkill
{
    public AIGRAVSkillInfo Info { get; } = new()
    {
        Name = "Legacy BIM Engine",
        Version = "1.0",
        Category = "Core",
        Description = "Adapter for the existing AIGRAVToolExecutor. All current AIGRAV tools remain available through this fallback skill.",
        Source = "AIGRAVToolExecutor.cs",
        Priority = -1000
    };

    public bool CanHandle(string toolName)
    {
        return !string.IsNullOrWhiteSpace(toolName);
    }

    public string Execute(string toolName, UIApplication app, string? argument = null)
    {
        if (!Info.IsEnabled)
        {
            return "AIGRAV Legacy BIM Engine is OFF.";
        }

        return AIGRAVToolExecutor.Execute(toolName, app, argument);
    }
}
