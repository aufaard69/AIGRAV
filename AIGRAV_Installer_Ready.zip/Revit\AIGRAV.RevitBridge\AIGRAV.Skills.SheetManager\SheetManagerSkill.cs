using System.Text.Json;
using AIGRAV.Contracts;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace AIGRAV.Skills.SheetManager;

public sealed class SheetManagerSkill : IAIGRAVSkill
{
    public AIGRAVSkillInfo Info { get; } = new()
    {
        Name = "Sheet Manager",
        Version = "1.0",
        Category = "Documentation",
        Description = "Manages sheets, views, and viewports for Revit documentation.",
        Source = "External",
        Priority = 1600
    };

    public bool CanHandle(string toolName)
    {
        return toolName.Equals("aigrav_inspect_views", StringComparison.OrdinalIgnoreCase) ||
               toolName.Equals("aigrav_place_viewport", StringComparison.OrdinalIgnoreCase) ||
               toolName.Equals("aigrav_setup_sheets", StringComparison.OrdinalIgnoreCase) ||
               toolName.Equals("aigrav_inspect_viewports", StringComparison.OrdinalIgnoreCase) ||
               toolName.Equals("aigrav_adjust_viewports", StringComparison.OrdinalIgnoreCase) ||
               toolName.Equals("aigrav_get_revision_clouds", StringComparison.OrdinalIgnoreCase) ||
               toolName.Equals("aigrav_delete_revision_clouds", StringComparison.OrdinalIgnoreCase) ||
               toolName.Equals("delete_revision_clouds", StringComparison.OrdinalIgnoreCase);
    }

    public string Execute(string toolName, UIApplication app, string? argument = null)
    {
        Document? doc = app?.ActiveUIDocument?.Document;
        if (doc == null) return "Sheet Manager failed: No active Revit document.";

        try
        {
            if (toolName.Equals("aigrav_inspect_views", StringComparison.OrdinalIgnoreCase))
            {
                return InspectViews(doc);
            }

            if (toolName.Equals("aigrav_place_viewport", StringComparison.OrdinalIgnoreCase))
            {
                return PlaceViewport(doc, argument);
            }

            if (toolName.Equals("aigrav_setup_sheets", StringComparison.OrdinalIgnoreCase))
            {
                return SetupSheets(doc, argument);
            }

            if (toolName.Equals("aigrav_inspect_viewports", StringComparison.OrdinalIgnoreCase))
            {
                return InspectViewports(doc, argument);
            }

            if (toolName.Equals("aigrav_adjust_viewports", StringComparison.OrdinalIgnoreCase))
            {
                return AdjustViewports(doc, argument);
            }

            if (toolName.Equals("aigrav_get_revision_clouds", StringComparison.OrdinalIgnoreCase))
            {
                return GetRevisionClouds(doc);
            }

            if (toolName.Equals("aigrav_delete_revision_clouds", StringComparison.OrdinalIgnoreCase) ||
                toolName.Equals("delete_revision_clouds", StringComparison.OrdinalIgnoreCase))
            {
                return DeleteRevisionClouds(doc);
            }

            return $"Unknown tool: {toolName}";
        }
        catch (Exception ex)
        {
            return $"Sheet Manager execution error: {ex}";
        }
    }

    private static string InspectViews(Document doc)
    {
        List<View> views = new FilteredElementCollector(doc)
            .OfClass(typeof(View))
            .Cast<View>()
            .Where(v => !v.IsTemplate)
            .OrderBy(v => v.ViewType.ToString())
            .ThenBy(v => v.Name)
            .ToList();

        var result = views.Select(v => new
        {
            Id = v.Id.Value,
            Name = v.Name,
            Type = v.ViewType.ToString(),
            Scale = v.Scale
        });

        return JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true });
    }

    private static string PlaceViewport(Document doc, string? argument)
    {
        if (string.IsNullOrWhiteSpace(argument)) return "PlaceViewport failed: Argument required.";

        using JsonDocument jdoc = JsonDocument.Parse(argument);
        JsonElement root = jdoc.RootElement;

        long sheetIdVal = root.GetProperty("sheetId").GetInt64();
        long viewIdVal = root.GetProperty("viewId").GetInt64();
        double x = root.GetProperty("x").GetDouble();
        double y = root.GetProperty("y").GetDouble();

        ElementId sheetId = new(sheetIdVal);
        ElementId viewId = new(viewIdVal);

        using Transaction tx = new(doc, "AIGRAV - Place Viewport");
        tx.Start();

        if (!Viewport.CanAddViewToSheet(doc, sheetId, viewId))
        {
            tx.RollBack();
            return $"Cannot add view {viewIdVal} to sheet {sheetIdVal}. (View might already be placed on a sheet)";
        }

        XYZ center = new(x, y, 0);
        Viewport vp = Viewport.Create(doc, sheetId, viewId, center);

        tx.Commit();
        return $"Viewport created successfully (Id: {vp.Id.Value}) at ({x}, {y})";
    }

    private static string SetupSheets(Document doc, string? argument)
    {
        // Find TitleBlock "KOP GAMBAR A3 - NTS"
        Element? tbType = new FilteredElementCollector(doc)
            .OfCategory(BuiltInCategory.OST_TitleBlocks)
            .WhereElementIsElementType()
            .FirstOrDefault(e => e.Name.Contains("KOP GAMBAR A3", StringComparison.OrdinalIgnoreCase));

        ElementId tbId = tbType != null ? tbType.Id : ElementId.InvalidElementId;

        // Target sheets:
        // PN-BG-001: BARIER GATE MOTOR
        // PN-BG-002: DETAIL ATAP KANOPI BARIER GATE MOTOR
        // PN-BG-003: DETAIL PONDASI KANOPI BARIER GATE
        // PN-BG-004: DETAIL TIANG RF-ID & CCTV
        // PN-BG-005: DETAIL BARIER GATE & PAGAR BRC

        var targets = new (string Number, string Name)[]
        {
            ("PN-BG-001", "BARIER GATE MOTOR"),
            ("PN-BG-002", "DETAIL ATAP KANOPI BARIER GATE MOTOR"),
            ("PN-BG-003", "DETAIL PONDASI KANOPI BARIER GATE"),
            ("PN-BG-004", "DETAIL TIANG RF-ID & CCTV"),
            ("PN-BG-005", "DETAIL BARIER GATE & PAGAR BRC")
        };

        var existingSheets = new FilteredElementCollector(doc)
            .OfClass(typeof(ViewSheet))
            .Cast<ViewSheet>()
            .ToList();

        List<string> logs = new();

        using Transaction tx = new(doc, "AIGRAV - Setup Sheets");
        tx.Start();

        foreach (var (number, name) in targets)
        {
            ViewSheet? s = existingSheets.FirstOrDefault(x => string.Equals(x.SheetNumber, number, StringComparison.OrdinalIgnoreCase));
            if (s != null)
            {
                s.Name = name;
                logs.Add($"Existing Sheet updated: {number} - {name} (Id: {s.Id.Value})");
            }
            else
            {
                ViewSheet newSheet = ViewSheet.Create(doc, tbId);
                newSheet.SheetNumber = number;
                newSheet.Name = name;
                logs.Add($"Created Sheet: {number} - {name} (Id: {newSheet.Id.Value})");
            }
        }

        tx.Commit();
        return string.Join("\n", logs);
    }

    private static string InspectViewports(Document doc, string? argument)
    {
        var vps = new FilteredElementCollector(doc)
            .OfClass(typeof(Viewport))
            .Cast<Viewport>()
            .ToList();

        var details = vps.Select(vp =>
        {
            ViewSheet? sheet = doc.GetElement(vp.SheetId) as ViewSheet;
            View? view = doc.GetElement(vp.ViewId) as View;
            XYZ center = vp.GetBoxCenter();
            Outline outline = vp.GetBoxOutline();

            return new
            {
                ViewportId = vp.Id.Value,
                SheetNumber = sheet?.SheetNumber ?? "",
                SheetName = sheet?.Name ?? "",
                ViewName = view?.Name ?? "",
                CenterX = center.X,
                CenterY = center.Y,
                OutlineMinX = outline.MinimumPoint.X,
                OutlineMinY = outline.MinimumPoint.Y,
                OutlineMaxX = outline.MaximumPoint.X,
                OutlineMaxY = outline.MaximumPoint.Y
            };
        });

        return JsonSerializer.Serialize(details, new JsonSerializerOptions { WriteIndented = true });
    }

    private static string AdjustViewports(Document doc, string? argument)
    {
        if (string.IsNullOrWhiteSpace(argument)) return "AdjustViewports failed: argument required.";

        using JsonDocument jdoc = JsonDocument.Parse(argument);
        JsonElement root = jdoc.RootElement;

        List<string> logs = new();

        using Transaction tx = new(doc, "AIGRAV - Adjust Viewports");
        tx.Start();

        foreach (JsonElement item in root.EnumerateArray())
        {
            long vpIdVal = item.GetProperty("viewportId").GetInt64();
            Viewport? vp = doc.GetElement(new ElementId(vpIdVal)) as Viewport;
            if (vp == null) continue;

            if (item.TryGetProperty("x", out JsonElement xElem) && item.TryGetProperty("y", out JsonElement yElem))
            {
                double x = xElem.GetDouble();
                double y = yElem.GetDouble();
                vp.SetBoxCenter(new XYZ(x, y, 0));
                logs.Add($"Viewport {vpIdVal} center set to ({x:F3}, {y:F3})");
            }

            if (item.TryGetProperty("labelLineLength", out JsonElement lenElem))
            {
                double len = lenElem.GetDouble();
                try
                {
                    vp.LabelLineLength = len;
                    logs.Add($"Viewport {vpIdVal} LabelLineLength set to {len:F3}");
                }
                catch (Exception ex)
                {
                    logs.Add($"Viewport {vpIdVal} LabelLineLength error: {ex.Message}");
                }
            }

            if (item.TryGetProperty("labelOffset", out JsonElement offElem))
            {
                double ox = offElem.GetProperty("x").GetDouble();
                double oy = offElem.GetProperty("y").GetDouble();
                try
                {
                    vp.LabelOffset = new XYZ(ox, oy, 0);
                    logs.Add($"Viewport {vpIdVal} LabelOffset set to ({ox:F3}, {oy:F3})");
                }
                catch (Exception ex)
                {
                    logs.Add($"Viewport {vpIdVal} LabelOffset error: {ex.Message}");
                }
            }
        }

        tx.Commit();
        return string.Join("\n", logs);
    }

    private static string GetRevisionClouds(Document doc)
    {
        var clouds = new FilteredElementCollector(doc)
            .OfCategory(BuiltInCategory.OST_RevisionClouds)
            .WhereElementIsNotElementType()
            .ToList();

        if (clouds.Count == 0) return "No revision clouds found in the project.";

        var list = clouds.Select(c => new
        {
            Id = c.Id.Value,
            OwnerViewId = c.OwnerViewId.Value,
            ViewName = doc.GetElement(c.OwnerViewId)?.Name ?? "Unknown"
        });

        return JsonSerializer.Serialize(list, new JsonSerializerOptions { WriteIndented = true });
    }

    private static string DeleteRevisionClouds(Document doc)
    {
        var cloudIds = new FilteredElementCollector(doc)
            .OfCategory(BuiltInCategory.OST_RevisionClouds)
            .WhereElementIsNotElementType()
            .ToElementIds();

        if (cloudIds.Count == 0)
        {
            return "No revision clouds found in the active project.";
        }

        int count = cloudIds.Count;
        using (Transaction t = new Transaction(doc, "AIGRAV - Delete All Revision Clouds"))
        {
            t.Start();
            var deleted = doc.Delete(cloudIds);
            t.Commit();
            return $"Successfully deleted {count} revision cloud(s) from project (Total affected elements: {deleted.Count}).";
        }
    }
}
