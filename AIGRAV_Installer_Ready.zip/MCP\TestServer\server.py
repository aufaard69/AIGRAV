import json
import urllib.request
import urllib.error
from typing import Any

from mcp.server import MCPServer


# ============================================================
# AIGRAV MCP SERVER
# Compatible with MCP SDK 2.3.0
# ============================================================

mcp = MCPServer("AIGRAV MCP Server")

AIGRAV_URL = "http://127.0.0.1:8765/"
AIGRAV_TIMEOUT = 60


# ============================================================
# HTTP BRIDGE
# ============================================================

def call_aigrav(
    tool: str,
    argument: str | None = None,
) -> str:

    payload: dict[str, Any] = {
        "tool": tool
    }

    if argument is not None:
        payload["argument"] = argument

    data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(
        AIGRAV_URL,
        data=data,
        headers={
            "Content-Type": "application/json"
        },
        method="POST",
    )

    try:

        with urllib.request.urlopen(
            request,
            timeout=AIGRAV_TIMEOUT,
        ) as response:

            response_data = (
                response
                .read()
                .decode("utf-8")
            )

            result = json.loads(
                response_data
            )

            success = result.get(
                "Success",
                result.get(
                    "success",
                    False
                )
            )

            result_text = result.get(
                "Result",
                result.get(
                    "result",
                    ""
                )
            )

            if not success:

                return (
                    "AIGRAV Error: "
                    + str(result_text)
                )

            return str(result_text)

    except urllib.error.URLError as ex:

        return (
            "AIGRAV Revit Bridge is not available. "
            f"Details: {ex}"
        )

    except Exception as ex:

        return (
            "AIGRAV MCP Error: "
            f"{ex}"
        )


# ============================================================
# GENERIC TOOL FACTORY
# ============================================================

def create_tool_function(
    tool_name: str,
    description: str,
):

    bridge_tool_name = tool_name
    if bridge_tool_name.startswith("aigrav_"):
        bridge_tool_name = bridge_tool_name[len("aigrav_"):]

    def tool_function(
        argument: str = "",
    ) -> str:

        return call_aigrav(
            bridge_tool_name,
            argument,
        )

    tool_function.__name__ = tool_name

    tool_function.__doc__ = description

    return tool_function


# ============================================================
# TOOL CATALOG
# ============================================================

TOOLS = {

    # --------------------------------------------------------
    # PROJECT / CONTEXT
    # --------------------------------------------------------

    "aigrav_ping":
        "Check whether the AIGRAV MCP server is running.",

    "aigrav_get_revit_info":
        "Get active Revit project information.",

    "aigrav_get_active_view":
        "Get the currently active Revit view.",

    "aigrav_get_selection":
        "Get currently selected Revit elements.",

    "aigrav_get_element":
        "Get basic information about a Revit element.",

    "aigrav_get_project_units":
        "Get project unit settings.",

    "aigrav_get_worksharing_info":
        "Get Revit worksharing information.",

    "aigrav_get_project_location":
        "Get Revit project location information.",

    "aigrav_get_phases":
        "Get project phases.",

    "aigrav_get_design_options":
        "Get project design options.",


    # --------------------------------------------------------
    # MODEL QUERY
    # --------------------------------------------------------

    "aigrav_get_categories":
        "Get categories available in the Revit model.",

    "aigrav_get_levels":
        "Get all levels in the current Revit document.",

    "aigrav_get_grids":
        "Get all grids in the current Revit document.",

    "aigrav_get_families":
        "Get loaded Revit families.",

    "aigrav_get_family_types":
        "Get available family types.",

    "aigrav_get_elements_by_category":
        "Get elements filtered by category.",

    "aigrav_get_elements_by_class":
        "Get elements filtered by Revit class.",

    "aigrav_get_elements_by_type":
        "Get elements belonging to a specified type.",

    "aigrav_get_elements_by_family":
        "Get elements belonging to a specified family.",

    "aigrav_get_elements_by_level":
        "Get elements associated with a level.",

    "aigrav_get_elements_in_view":
        "Get elements visible in a specified view.",

    "aigrav_get_elements_in_category":
        "Get elements from a specified category.",

    "aigrav_get_structural_elements":
        "Get structural elements from the model.",

    "aigrav_get_architecture_elements":
        "Get architectural elements from the model.",

    "aigrav_get_mep_elements":
        "Get MEP elements from the model.",

    "aigrav_get_walls":
        "Get walls from the model.",

    "aigrav_get_floors":
        "Get floors from the model.",

    "aigrav_get_roofs":
        "Get roofs from the model.",

    "aigrav_get_columns":
        "Get structural columns from the model.",

    "aigrav_get_beams":
        "Get structural framing elements.",

    "aigrav_get_doors":
        "Get doors from the model.",

    "aigrav_get_windows":
        "Get windows from the model.",

    "aigrav_get_rooms":
        "Get rooms from the model.",

    "aigrav_get_spaces":
        "Get MEP spaces from the model.",

    "aigrav_get_sheets":
        "Get sheets from the model.",

    "aigrav_get_views":
        "Get views from the model.",

    "aigrav_get_schedules":
        "Get schedules from the model.",

    "aigrav_get_materials":
        "Get materials from the model.",

    "aigrav_get_worksets":
        "Get worksets from the model.",

    "aigrav_get_links":
        "Get linked Revit models.",

    "aigrav_get_warnings":
        "Get current Revit warnings.",

    "aigrav_get_document_counts":
        "Get element counts in the document.",


    # --------------------------------------------------------
    # ELEMENT INTELLIGENCE
    # --------------------------------------------------------

    "aigrav_get_element_parameters":
        "Get parameters of a Revit element.",

    "aigrav_get_element_location":
        "Get the location of a Revit element.",

    "aigrav_get_element_bounding_box":
        "Get the bounding box of a Revit element.",

    "aigrav_get_element_type":
        "Get the type of a Revit element.",

    "aigrav_get_element_family":
        "Get the family of a Revit element.",

    "aigrav_get_element_level":
        "Get the level associated with a Revit element.",

    "aigrav_get_element_dimensions":
        "Get dimensions of a Revit element.",

    "aigrav_get_element_materials":
        "Get materials associated with a Revit element.",

    "aigrav_get_element_geometry":
        "Get geometry information for a Revit element.",

    "aigrav_get_element_host":
        "Get host information for a Revit element.",

    "aigrav_get_element_dependents":
        "Get dependent elements.",

    "aigrav_get_element_dependent_elements":
        "Get elements dependent on a given element.",

    "aigrav_get_element_constraints":
        "Get constraint information for an element.",

    "aigrav_get_element_joins":
        "Get join information for an element.",

    "aigrav_get_element_workset":
        "Get workset information for an element.",

    "aigrav_get_element_design_option":
        "Get design option information for an element.",

    "aigrav_get_element_phase":
        "Get phase information for an element.",

    "aigrav_get_element_created_phase":
        "Get created phase information.",

    "aigrav_get_element_demolished_phase":
        "Get demolished phase information.",

    "aigrav_get_element_category":
        "Get category information.",

    "aigrav_get_element_class":
        "Get Revit class information.",

    "aigrav_get_element_id":
        "Get element ID information.",

    "aigrav_get_element_name":
        "Get element name.",


    # --------------------------------------------------------
    # VIEW
    # --------------------------------------------------------

    "aigrav_activate_view":
        "Activate a Revit view.",

    "aigrav_rename_view":
        "Rename a Revit view.",

    "aigrav_duplicate_view":
        "Duplicate a Revit view.",

    "aigrav_set_view_scale":
        "Set the scale of a view.",

    "aigrav_get_view_elements":
        "Get elements visible in a view.",

    "aigrav_hide_elements":
        "Hide elements in a view.",

    "aigrav_unhide_elements":
        "Unhide elements in a view.",

    "aigrav_isolate_elements":
        "Temporarily isolate elements in a view.",

    "aigrav_get_view_detail_level":
        "Get view detail level.",

    "aigrav_set_view_detail_level":
        "Set view detail level.",

    "aigrav_get_view_discipline":
        "Get view discipline.",

    "aigrav_set_view_discipline":
        "Set view discipline.",

    "aigrav_get_view_properties":
        "Get view properties.",


    # --------------------------------------------------------
    # CREATE
    # --------------------------------------------------------

    "aigrav_create_level":
        "Create a new Revit level.",

    "aigrav_create_grid":
        "Create a new Revit grid.",

    "aigrav_create_wall":
        "Create a wall.",

    "aigrav_create_floor":
        "Create a floor.",

    "aigrav_create_column":
        "Create a structural column.",

    "aigrav_create_beam":
        "Create structural framing.",

    "aigrav_create_family_instance":
        "Create a family instance.",

    "aigrav_create_generic_model":
        "Create a generic model instance.",

    "aigrav_create_room":
        "Create a room.",

    "aigrav_create_area":
        "Create an area.",

    "aigrav_create_view":
        "Create a Revit view.",

    "aigrav_create_sheet":
        "Create a sheet.",

    "aigrav_create_dimension":
        "Create a dimension.",

    "aigrav_create_text_note":
        "Create a text note.",

    "aigrav_create_detail_curve":
        "Create a detail curve.",

    "aigrav_create_model_curve":
        "Create a model curve.",

    "aigrav_create_schedule":
        "Create a schedule.",


    # --------------------------------------------------------
    # MODIFY
    # --------------------------------------------------------

    "aigrav_set_parameter":
        "Set a Revit element parameter.",

    "aigrav_move_element":
        "Move a Revit element.",

    "aigrav_copy_element":
        "Copy a Revit element.",

    "aigrav_rotate_element":
        "Rotate a Revit element.",

    "aigrav_mirror_element":
        "Mirror a Revit element.",

    "aigrav_delete_element":
        "Delete a Revit element.",

    "aigrav_pin_element":
        "Pin a Revit element.",

    "aigrav_unpin_element":
        "Unpin a Revit element.",

    "aigrav_join_geometry":
        "Join geometry between elements.",

    "aigrav_unjoin_geometry":
        "Unjoin geometry between elements.",

    "aigrav_check_joined":
        "Check whether elements are joined.",

    "aigrav_switch_join_order":
        "Switch join order between elements.",

    "aigrav_change_type":
        "Change the type of an element.",

    "aigrav_change_level":
        "Change the level of an element.",

    "aigrav_set_location":
        "Set element location.",

    "aigrav_set_workset":
        "Set element workset.",

    "aigrav_set_phase":
        "Set element phase.",

    "aigrav_set_design_option":
        "Set design option.",

    "aigrav_set_comments":
        "Set element comments.",

    "aigrav_set_mark":
        "Set element mark.",

    "aigrav_set_name":
        "Set element name where supported.",

    "aigrav_change_wall_type":
        "Change wall type.",

    "aigrav_change_family_type":
        "Change family instance type.",

    "aigrav_change_view_template":
        "Change view template.",

    "aigrav_set_view_template":
        "Set view template.",

    "aigrav_set_view_crop":
        "Set view crop configuration.",

    "aigrav_set_visibility":
        "Set element visibility.",

    "aigrav_set_parameter_batch":
        "Set multiple parameters.",

    "aigrav_delete_elements":
        "Delete multiple elements.",

    "aigrav_move_elements":
        "Move multiple elements.",

    "aigrav_copy_elements":
        "Copy multiple elements.",

    "aigrav_rotate_elements":
        "Rotate multiple elements.",

    "aigrav_mirror_elements":
        "Mirror multiple elements.",

    "aigrav_pin_elements":
        "Pin multiple elements.",

    "aigrav_unpin_elements":
        "Unpin multiple elements.",

    "aigrav_join_elements":
        "Join multiple element pairs.",

    "aigrav_unjoin_elements":
        "Unjoin multiple element pairs.",

    "aigrav_rename_elements":
        "Rename multiple elements where supported.",

    "aigrav_regenerate":
        "Regenerate the Revit document.",


    # --------------------------------------------------------
    # DOCUMENT
    # --------------------------------------------------------

    "aigrav_save_document":
        "Save the active Revit document.",

    "aigrav_save_as":
        "Save the active document as another file.",

    "aigrav_sync_with_central":
        "Synchronize with central for workshared projects.",

    "aigrav_reload_latest":
        "Reload latest from central.",

    "aigrav_get_document_path":
        "Get document path.",

    "aigrav_get_document_title":
        "Get document title.",

    "aigrav_get_document_version":
        "Get document version.",

    "aigrav_get_document_state":
        "Get document state.",


    # --------------------------------------------------------
    # ANALYSIS
    # --------------------------------------------------------

    "aigrav_measure_distance":
        "Measure distance between points or elements.",

    "aigrav_get_element_length":
        "Get element length.",

    "aigrav_get_curve_endpoints":
        "Get curve endpoints.",

    "aigrav_validate_element":
        "Validate a Revit element.",

    "aigrav_validate_model":
        "Run model validation.",

    "aigrav_count_elements":
        "Count elements.",

    "aigrav_count_category":
        "Count elements by category.",

    "aigrav_find_duplicate_marks":
        "Find duplicate element marks.",

    "aigrav_find_duplicate_names":
        "Find duplicate names.",

    "aigrav_find_empty_parameters":
        "Find empty parameters.",

    "aigrav_find_warnings":
        "Find Revit warnings.",

    "aigrav_check_model_health":
        "Check general model health.",
}


# ============================================================
# REGISTER ALL TOOLS
# ============================================================

for _tool_name, _description in TOOLS.items():

    _function = create_tool_function(
        _tool_name,
        _description,
    )

    mcp.add_tool(
        _function,
        name=_tool_name,
        description=_description,
        structured_output=False,
    )


# ============================================================
# START MCP
# ============================================================

if __name__ == "__main__":

    mcp.run(
        transport="stdio"
    )