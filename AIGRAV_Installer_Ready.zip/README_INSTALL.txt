﻿========================================================================
                 AIGRAV INSTALLER PACKAGE FOR OTHER PC
========================================================================

SELAMAT! Paket instalasi AIGRAV ini sudah berisi:
 1. Database Baja & Profil (AIGRAV.SteelDatabase.csv, 230 profil WF & H-Beam)
 2. Database Sambungan Resmi SNI/STD (AIGRAV_SteelConnectionDatabase_v1.json)
 3. Library Family Revit (.rfa Base Plate WF 400, End Plate WF 400)
 4. Binary Revit Bridge Precompiled (.NET 10 / Revit 2024, 2025, 2026, 2027)
 5. Server MCP Python (50+ Revit Automation Tools)
 6. Plugin Antigravity (aigrav-bim, skill QTO Schedule Audit, install-aigrav)
 7. Standard Operating Protocol (AGENTS.md)

------------------------------------------------------------------------
CARA 1: INSTALASI MELALUI ANTIGRAVITY (PALING MUDAH)
------------------------------------------------------------------------
1. Copy folder installer ini ke PC baru (direkomendasikan letakkan di C:\AIGRAV).
2. Buka aplikasi Antigravity di PC tersebut.
3. Di chat prompt Antigravity, cukup ketik:
   "install aigrav"  atau  "instalkan aigrav sekarang"
4. Antigravity akan otomatis mendeteksi script installer, menginstal add-in Revit,
   menyiapkan runtime Python MCP, mengonfigurasi mcp_config.json, dan melaporkan
   status instalasi sampai selesai!

------------------------------------------------------------------------
CARA 2: DOUBLE-CLICK INSTALLER WINDOWS (TANPA PROMPT)
------------------------------------------------------------------------
1. Klik kanan pada file "install.bat"
2. Pilih "Run as administrator" (atau double click biasa)
3. Tunggu hingga proses instalasi menampilkan:
   "AIGRAV INSTALLATION COMPLETED SUCCESSFULLY!"
4. Buka Autodesk Revit -> Plugin AIGRAV langsung aktif di Ribbon.
5. Buka Antigravity -> Siap digunakan!

------------------------------------------------------------------------
VERIFIKASI SETELAH INSTALL:
------------------------------------------------------------------------
Jalankan di PowerShell:
  powershell -ExecutionPolicy Bypass -File C:\AIGRAV\Verify-AIGRAV.ps1

========================================================================
